%This function tests the parameter sets and concentrations which have been
%pre-calculated using the Numerical_Solver_GitHub for the network with the
%loop

clear
Network_to_analyse = load('Network_loop_uniform_interval_0_20.csv','w');
Network_to_analyse(1,:)=[];
%Network_to_analyse=unique(Network_to_analyse, 'rows'); <-just test the
%size of this first to ensure the parameter sets are all unique
 %csvwrite('Unique values.csv',Network_to_analyse)
table_size=size(Network_to_analyse);
num_times_cond_NOT_hold=0;
 number_of_failed_experiments=0;
 sat_cond_but_not_pattern=zeros(1,20);
 y=zeros(1,20);
q=zeros(1,20);

do_not_pattern=zeros(1,32 );
not_sat_cond_and_not_pattern=zeros(1,32 );
Long_success=zeros(1,31 );
success_vector=zeros(1, 20);
wrong_stuff=zeros(1,32);
 
 for i=1:length(Network_to_analyse)
%extract the parameters fromt he file
    AUXp=Network_to_analyse(i,1);
    Fa=Network_to_analyse(i,2);
    CKp= Network_to_analyse(i,3);
    TDIF=Network_to_analyse(i,4);
    d_Aux=Network_to_analyse(i,5);
    d_PIN=Network_to_analyse(i,6);
    d_MP=Network_to_analyse(i,7);
    d_CK=Network_to_analyse(i,8);
    d_PXY_in= Network_to_analyse(i,9);
    d_PXY_a=Network_to_analyse(i,10);
    r1=Network_to_analyse(i,11);
    r2=Network_to_analyse(i,12);
    r3=Network_to_analyse(i,13);
    r4=Network_to_analyse(i,14);
    r5=Network_to_analyse(i,15);
    r6=Network_to_analyse(i,16);
    r7=Network_to_analyse(i,17);
    r8=Network_to_analyse(i,18);
    AUXc=Network_to_analyse(i,22);
    AUXx=Network_to_analyse(i,23);
    CKc=Network_to_analyse(i,24);
    CKx=Network_to_analyse(i,25);
    PINc=Network_to_analyse(i,26);
    PINx=Network_to_analyse(i,27);
    MPc=Network_to_analyse(i,28);  
    MPx=Network_to_analyse(i,29);
    PXYin=Network_to_analyse(i,30);
    PXYa=Network_to_analyse(i,31);
    %calculate condition for the full network with the negative feedback
    %loop
    condition_to_check=Fa-d_Aux;
    condition_to_check=condition_to_check -0.5*(r8*r5*r6*AUXp)/((r7*CKp+d_PIN)*(r3*PXYa+d_MP));
   
    
    Result=logical(AUXc>AUXp);
    Result2=logical(AUXc>AUXx);
     parameter_vector=[AUXp,Fa, CKp, TDIF, d_Aux,...
    d_PIN,d_MP,d_CK,d_PXY_in, d_PXY_a,r1,r2,r3,r4,r5,r6,r7,r8,PXYa, condition_to_check];
     %how many experiments failed?
     long=[AUXp,Fa, CKp, TDIF, d_Aux,...
    d_PIN,d_MP,d_CK,d_PXY_in, d_PXY_a,...
    r1,r2,r3,r4,r5,r6,r7,r8,PXYa,999,999,999,...
    AUXc,AUXx,CKc,CKx, PINc, PINx,MPc,MPx,PXYin, condition_to_check];
     parameter_vector_long=[AUXp,Fa, CKp, TDIF, d_Aux,...
    d_PIN,d_MP,d_CK,d_PXY_in, d_PXY_a,r1,r2,r3,r4,r5,r6,r7,r8,999,...
    999,999,AUXc,AUXx,CKc,CKx...
    ,PINc,PINx, MPc, MPx, PXYin, PXYa];
%% All of the parameter sets for which condition is satisfied but the pattern is not achieved



     if (Result==0)&&(condition_to_check>0)
         number_of_failed_experiments=number_of_failed_experiments+1;
          sat_cond_but_not_pattern=vertcat(sat_cond_but_not_pattern,parameter_vector);%store the parameters to check for condition 2
     end

     %% all parameter sets and concentrations which just don't pattern
     if (Result==0)
  
         do_not_pattern=vertcat(do_not_pattern, long);
         
        
     end
     %% the conditions are satisfied but there is a pattern
       
      if (Result==1)&&(condition_to_check<0)
        
         wrong_stuff=vertcat(wrong_stuff, long);
         
        
     end
     %%   don't satisfy condition and don't pattern
        if (Result==0)&&(condition_to_check<0)
        
         not_sat_cond_and_not_pattern=vertcat(not_sat_cond_and_not_pattern, long);
         
        
     end
     
     
     
     %% All that satisfy condition
    
          if (Result==1)
              success_vector=vertcat(success_vector, parameter_vector);
              Long_success=vertcat(Long_success,parameter_vector_long);
          end
       
          
 end 
 size_success=size(success_vector);
 size_success(1,1)=size_success(1,1)-1;
    percentage_success=100*size_success(1,1)/table_size(1,1);
vector=[table_size(1,1) size_success(1,1)  percentage_success];
 csvwrite('All parameters that satisfy condition but not pattern.csv',sat_cond_but_not_pattern)
    csvwrite('All parameters that do not satisfy condition and do not pattern.csv',not_sat_cond_and_not_pattern)
     csvwrite('All parameters that do not satisfy condition and pattern.csv',wrong_stuff)
   csvwrite('All parameters that do not pattern.csv',do_not_pattern)
csvwrite('Successful parameter sets_long.csv', Long_success);
csvwrite('Vector with percentage success.csv', vector)

dlmwrite('All parameters that satisfy condition but not pattern_long.csv',sat_cond_but_not_pattern, 'precision', 9)
    dlmwrite('All parameters that do not satisfy condition and do not pattern_long.csv',not_sat_cond_and_not_pattern, 'precision', 9)
     dlmwrite('All parameters that do not satisfy condition and pattern_long.csv',wrong_stuff, 'precision', 9)
   dlmwrite('All parameters that do not pattern_long.csv',do_not_pattern, 'precision', 9)
dlmwrite('Successful parameter sets_long_long.csv', Long_success, 'precision', 9);
dlmwrite('Vector with percentage success_long.csv', vector, 'precision', 9)