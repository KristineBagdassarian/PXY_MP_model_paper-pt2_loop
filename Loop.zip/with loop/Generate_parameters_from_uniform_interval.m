%This programme generates parameters from a uniform interval.
%Successful_paramters=unique(Successful_paramters, 'rows');

number_of_parameter_sets=2500;

 %[a, b] is the interval from which the parameters for the loop are
  %randomly selected
   a = 0.001;
   b = 20;
   parameters_sets=zeros(1, 18);
 c=20;
for i=1:number_of_parameter_sets
        
        i;
                      
            AUXp=(b-a).*rand(1) + a; 
            Fa=(b-a).*rand(1) + a; 
            CKp=(b-a).*rand(1) + a; 
            TDIF=(b-a).*rand(1) + a; 
            d_Aux=(b-a).*rand(1) + a; 
            d_PIN=(b-a).*rand(1) + a; 
            d_MP=(c-a).*rand(1) + a; 
            d_CK=(b-a).*rand(1) + a; 
            d_PXY_in= (b-a).*rand(1) + a; 
            d_PXY_a=(b-a).*rand(1) + a; 
            r1=(b-a).*rand(1) + a; 
            r2=(b-a).*rand(1) + a;
            r3=(b-a).*rand(1) + a;
            r4=(b-a).*rand(1) + a;
            r5=(b-a).*rand(1) + a; 
            r6=(b-a).*rand(1) + a; 
            r7=(b-a).*rand(1) + a; 
            r8=(b-a).*rand(1) + a; 
                     
        
        parameter_vector=[AUXp,Fa, CKp, TDIF, d_Aux, d_PIN, ...
            d_MP, d_CK, d_PXY_in, d_PXY_a, r1, r2, r3, r4, r5, r6, r7, r8];
     
                   parameters_sets=vertcat( parameters_sets,parameter_vector);  
 
 end 
csvwrite('Parameters_with_loop_0__20.csv',parameters_sets) 
dlmwrite('Parameters_with_loop_0__20_long.csv',parameters_sets, 'precision', '%i')
%size(unique( parameters_sets, 'rows'))